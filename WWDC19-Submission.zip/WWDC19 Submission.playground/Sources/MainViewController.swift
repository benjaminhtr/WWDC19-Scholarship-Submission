import UIKit
import AVFoundation
import Vision

public var canvas: Canvas!
public var applyButton: Button!

public class MainViewController: UIViewController {
    private var drawNumberLabel: UILabel!
    private var speakButton: UIButton!
    private var canvasView: CanvasView!
    private var seperator: UIView!
    private var rightDetailView: UIView!
    private var rightDetailViewImageView: UIImageView!
    private var pointsLabel: UILabel!
    private var predictLabel: UILabel!
    private var clearButton: Button!
    
    private var latestResult: MNISTOutput?
    
    private let viewHeight: Int = 440
    private let viewWidth: Int = 640
    
    private let synth = AVSpeechSynthesizer()
    
    private var points: Int = 0 {
        didSet {
            pointsLabel.text = "Points: \(points)"
        }
    }
    
    private var requests = [VNRequest]()
    
    override public func viewDidLoad() {
        super.viewDidLoad()
        
        view.backgroundColor = UIColor.systemDarkPurple
        view.alpha = 0
        setupVision()
        
        drawNumberLabel = {
            let label = UILabel(frame: CGRect(x: 40, y: 34, width: 320, height: 26))
            let attributedString = NSMutableAttributedString(string: "Draw a \(Int.random(in: 0...9))")
            attributedString.setColor(color: UIColor.systemGray, forText: "Draw a")
            label.textColor = #colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)
            label.attributedText = attributedString
            label.font = UIFont.monospacedDigitSystemFont(ofSize: 22, weight: .bold)
            label.textAlignment = .center
            return label
        }()
        view.addSubview(drawNumberLabel)
        
        speakButton = {
            let button = UIButton(type: .system)
            button.frame = CGRect(x: 120, y: drawNumberLabel.frame.origin.y, width: drawNumberLabel.frame.height, height: drawNumberLabel.frame.height)
            button.setImage(UIImage(named: "audio@3x"), for: .normal)
            button.tintColor = #colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)
            button.addTarget(self, action: #selector(speak), for: .touchUpInside)
            return button
        }()
        view.addSubview(speakButton)
        
        canvasView = {
            let view = CanvasView(frame: CGRect(x: 40, y: 75, width: 320, height: 320))
            return view
        }()
        view.addSubview(canvasView)
        
        seperator = {
            let view = UIView(frame: CGRect(x: 399, y: 0, width: 1, height: viewHeight))
            view.backgroundColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 0.08)
            return view
        }()
        view.addSubview(seperator)
        
        rightDetailView = {
            let view = UIView(frame: CGRect(x: 420, y: 20, width: 200, height: 61))
            view.backgroundColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
            view.layer.cornerRadius = 10
            view.layer.shadowColor = UIColor.black.cgColor
            view.layer.shadowOffset = CGSize(width: 0, height: 4)
            view.layer.shadowRadius = 5
            view.layer.shadowOpacity = 0.1
            return view
        }()
        view.addSubview(rightDetailView)
        
        rightDetailViewImageView = {
            let imageView = UIImageView(frame: CGRect(x: 66, y: 10, width: 68, height: 41))
            imageView.image = UIImage(named: "technologies2")
            return imageView
        }()
        rightDetailView.addSubview(rightDetailViewImageView)
        
        pointsLabel = {
            let label = UILabel(frame: CGRect(x: 440, y: 191, width: 160, height: 24))
            label.text = "Points: \(points)"
            label.font = UIFont.monospacedDigitSystemFont(ofSize: 20, weight: .bold)
            label.textColor = #colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)
            label.textAlignment = .center
            return label
        }()
        view.addSubview(pointsLabel)
        
        predictLabel = {
            let label = UILabel(frame: CGRect(x: 440, y: 220, width: 160, height: 15))
            label.font = UIFont.systemFont(ofSize: 13, weight: .semibold)
            label.textColor = UIColor.systemBlue
            label.textAlignment = .center
            return label
        }()
        view.addSubview(predictLabel)
        
        clearButton = {
            let button = Button(frame: CGRect(x: 440, y: 313, width: 160, height: 36), cornerRadius: 5)
            button.setImage(UIImage(named: "clearIcon@3x"), for: .normal)
            button.setButtonStyle(.gray)
            button.tintColor = #colorLiteral(red: 0, green: 0, blue: 0, alpha: 1)
            button.addTarget(self, action: #selector(clear), for: .touchUpInside)
            button.isButtonEnabled(true)
            return button
        }()
        view.addSubview(clearButton)
        
        applyButton = {
            let button = Button(frame: CGRect(x: 440, y: 359, width: 160, height: 36), cornerRadius: 5)
            
            button.setImage(UIImage(named: "applyIcon@3x"), for: .normal)
            button.tintColor = #colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)
            button.layer.shadowColor = UIColor.black.cgColor
            button.layer.shadowOffset = CGSize(width: 0, height: 2)
            button.layer.shadowRadius = 2.5
            button.layer.shadowOpacity = 0.16
            button.addTarget(self, action: #selector(apply), for: .touchUpInside)
            return button
        }()
        view.addSubview(applyButton)
    }
    
    func setupVision() {
        guard let visionModel = try? VNCoreMLModel(for: MNIST().model) else {fatalError("Cannot load Vision ML model")}
        
        let classificationRequest = VNCoreMLRequest(model: visionModel, completionHandler: self.handleClassification)
        
        self.requests = [classificationRequest]
    }
    
    func handleClassification(request: VNRequest, error: Error?) {
        guard let observations = request.results else {
            print("No results")
            return
        }
        
        let classifications = observations
            .compactMap({$0 as? VNClassificationObservation})
            .filter({$0.confidence > 0.8})
            .map({$0.identifier})
        
        DispatchQueue.main.async {
            let numberText = classifications.first!
            
            let string = String(self.drawNumberLabel.text!)
            let stringArray = string.components(separatedBy: CharacterSet.decimalDigits.inverted)
            for item in stringArray {
                if let number = Int(item) {
                    if number == Int(numberText) {
                        self.points += 5
                        self.predictLabel.text = "Last predict: \(numberText) ✓"
                        print("Right!")
                        
                        if self.points == 25 || self.points == 50 || self.points == 100 {
                            self.congrats()
                        } else {
                            playSound(.success)
                        }
                    } else {
                        self.points -= 5
                        self.predictLabel.text = "Last predict: \(numberText) 𐄂"
                        print("Wrong!")
                        playSound(.error)
                    }
                    print("Predict: \(numberText)")
                }
            }
            
            let attributedString = NSMutableAttributedString(string: "Draw a \(Int.random(in: 0...9))")
            attributedString.setColor(color: UIColor.systemGray, forText: "Draw a")
            self.drawNumberLabel.attributedText = attributedString
        }
    }
    
    public func congrats() {
        let message: String = "You reached \(points) points! Thank you for playing the playground. Below you can reset your progress or you can continue."
        
        let alertController = UIAlertController(title: "Congratulations! 🥳", message: message, preferredStyle: .alert)
        alertController.view.tintColor = UIColor.systemBlue
        alertController.addAction(UIAlertAction(title: "Continue", style: .default, handler: continuePressed))
        alertController.addAction(UIAlertAction(title: "Reset", style: .cancel, handler: reset))
        present(alertController, animated: true, completion: nil)
        
        playSound(.yay)
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 3.5) {
            let utterance = AVSpeechUtterance(string: "Congratulations!" + message)
            utterance.voice = AVSpeechSynthesisVoice(language: "en")
            
            self.synth.speak(utterance)
        }
    }
    
    func continuePressed(alert: UIAlertAction!) {
        synth.stopSpeaking(at: .immediate)
    }
    
    func reset(alert: UIAlertAction!) {
        points = 0
        pointsLabel.text = "Points: \(self.points)"
        predictLabel.text = nil
        synth.stopSpeaking(at: .immediate)
    }
    
    @objc func speak() {
        let message = AVSpeechUtterance(string: drawNumberLabel.text!)
        message.voice = AVSpeechSynthesisVoice(language: "en")
        
        let synth = AVSpeechSynthesizer()
        synth.speak(message)
        
        playSound(.pop)
    }
    
    @objc public func clear() {
        canvas.clearCanvas(true)
        playSound(.pop)
    }
    
    @objc public func apply() {
        canvas.clearCanvas(true)
        applyButton.isButtonEnabled(false)
        
        let image = UIImage(view: Canvas()).resize(to: CGSize(width: 28, height: 28))
        
        let imageRequestHandler = VNImageRequestHandler(cgImage: (image?.cgImage)!, options: [:])
        
        do {
            try imageRequestHandler.perform(self.requests)
        } catch {
            print(error)
        }
    }
    
    override public func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(true)
        
        UIView.animate(withDuration: 0.5) {
            self.view.alpha = 1
        }
    }
}
