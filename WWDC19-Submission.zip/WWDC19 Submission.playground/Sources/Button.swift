import UIKit

public class Button: UIButton {
    
    private var CornerRadius: CGFloat
    
    public init(frame: CGRect, cornerRadius: CGFloat) {
        CornerRadius = cornerRadius
        super.init(frame: frame)
        
        setButtonStyle(.blue)
        isButtonEnabled(false)
        layer.cornerRadius = CornerRadius
        adjustsImageWhenHighlighted = false
        
        addTarget(self, action: #selector(holdingDown), for: .touchDown)
        addTarget(self, action: #selector(holdingDown), for: .touchDragInside)
        addTarget(self, action: #selector(holdingUp), for: .touchUpInside)
        addTarget(self, action: #selector(holdingUp), for: .touchDragOutside)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    public enum ButtonStyle {
        case blue, gray
    }
    
    public func setButtonStyle(_ theme: ButtonStyle) {
        switch theme {
        case ButtonStyle.blue:
            backgroundColor = UIColor.systemBlue
        default:
            backgroundColor = #colorLiteral(red: 0.9333333333, green: 0.9333333333, blue: 0.9333333333, alpha: 1)
        }
    }
    
    @objc func holdingDown() {
        UIView.animate(withDuration: 0.15, delay: 0, options: .curveEaseInOut, animations: {
            self.transform = CGAffineTransform(scaleX: 0.95, y: 0.95)
        }, completion: nil)
    }
    
    @objc func holdingUp() {
        UIView.animate(withDuration: 0.15, delay: 0, options: .curveEaseInOut, animations: {
            self.transform = CGAffineTransform(scaleX: 1, y: 1)
        }, completion: nil)
    }
    
    public func isButtonEnabled(_ enabled: Bool) {
        if enabled {
            isUserInteractionEnabled = true
            alpha = 1
        } else {
            isUserInteractionEnabled = false
            alpha = 0.5
        }
    }
}
