import UIKit

public class SquareView: UIView {
    private let viewHeight: Int = 440
    private let viewWidth: Int = 640
    
    override public func draw(_ rect: CGRect) {
        let path = drawSquare()
        path.stroke()
    }
    
    func drawSquare() -> UIBezierPath {
        let path = UIBezierPath()
        path.move(to: CGPoint(x: 0, y: 0))
        path.addLine(to: CGPoint(x: 390, y: 0))
        path.addLine(to: CGPoint(x: 250, y: viewHeight))
        path.addLine(to: CGPoint(x: 0, y: viewHeight))
        path.lineWidth = 0
        UIColor.systemDarkPurple.setFill()
        path.fill()
        path.close()
        return path
    }
}
