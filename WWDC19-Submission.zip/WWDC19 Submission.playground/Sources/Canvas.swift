import UIKit

public class Canvas: UIImageView {
    let π = CGFloat.pi
    
    let forceSensitivity: CGFloat = 4.0
    let minLineWidth: CGFloat = 5
    
    var minX = 0
    var minY = 0
    var maxX = 0
    var maxY = 0
    
    var ocrImageRect: CGRect?
    let defaultLineWidth: CGFloat = 6
    var context: CGContext?
    
    public var tutorialLabel: UILabel!
    
    public func setup() {
        resetRect()
        
        tutorialLabel = {
            let label = UILabel(frame: CGRect(x: 0, y: 0, width: 320 - 30, height: 320 - 30))
            label.text = "Touch and pan to\ndraw a number"
            label.numberOfLines = 2
            label.textColor = UIColor.systemGray
            label.font = UIFont.systemFont(ofSize: 14, weight: .regular)
            label.textAlignment = .center
            label.isHidden(false, animated: true)
            return label
        }()
        addSubview(tutorialLabel)
    }
    
    func resetRect() {
        minX = Int(self.frame.width)
        minY = Int(self.frame.height)
        
        maxX = 0
        maxY = 0
        
        UIGraphicsBeginImageContextWithOptions(bounds.size, false, 0.0)
        context = UIGraphicsGetCurrentContext()
    }
    
    override public func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        
        guard let touch = touches.first else {
            return
        }
        
        image?.draw(in: bounds)
        
        var touches = [UITouch]()
        if let coalescedTouches = event?.coalescedTouches(for: touch) {
            touches = coalescedTouches
        } else {
            touches.append(touch)
        }
        
        for touch in touches {
            drawStroke(context: context, touch: touch)
        }
        
        image = UIGraphicsGetImageFromCurrentImageContext()
        
        tutorialLabel.isHidden(true, animated: true)
        applyButton.isButtonEnabled(true)
    }
    
    func drawStroke(context: CGContext?, touch: UITouch) {
        let previousLocation = touch.previousLocation(in: self)
        
        var lineWidth: CGFloat = 25.0
        let tiltThreshold: CGFloat = π/6
        
        let location = touch.location(in: self)
        
        minX = min(minX, Int(location.x))
        minY = min(minY, Int(location.y))
        maxX = max(maxX, Int(location.x))
        maxY = max(maxY, Int(location.y))
        
        if touch.altitudeAngle < tiltThreshold {
            lineWidth = lineWidthForShading(context: context, touch: touch)
        } else {
            lineWidth = lineWidthForDrawing(context: context, touch: touch)
        }
        
        
        UIColor.white.setStroke()
        
        context!.setLineWidth(lineWidth)
        context!.setLineCap(.round)
        
        context?.move(to: previousLocation)
        context?.addLine(to: location)
        
        context!.strokePath()
    }
    
    func lineWidthForShading(context: CGContext?, touch: UITouch) -> CGFloat {
        
        let previousLocation = touch.previousLocation(in: self)
        let location = touch.location(in: self)
        
        let vector1 = touch.azimuthUnitVector(in: self)
        
        let vector2 = CGPoint(x: location.x - previousLocation.x, y: location.y - previousLocation.y)
        
        var angle = abs(atan2(vector2.y, vector2.x) - atan2(vector1.dy, vector1.dx))
        
        if angle > π {
            angle = 2 * π - angle
        }
        if angle > π / 2 {
            angle = π - angle
        }
        
        let minAngle: CGFloat = 0
        let maxAngle = π / 2
        let normalizedAngle = (angle - minAngle) / (maxAngle - minAngle)
        
        let maxLineWidth: CGFloat = 60
        var lineWidth = maxLineWidth * normalizedAngle
        
        let tiltThreshold : CGFloat = π/6
        let minAltitudeAngle: CGFloat = 0.25
        let maxAltitudeAngle = tiltThreshold
        
        let altitudeAngle = touch.altitudeAngle < minAltitudeAngle ? minAltitudeAngle : touch.altitudeAngle
        
        let normalizedAltitude = 1 - ((altitudeAngle - minAltitudeAngle) / (maxAltitudeAngle - minAltitudeAngle))
        
        lineWidth = lineWidth * normalizedAltitude + minLineWidth
        
        let minForce: CGFloat = 0.0
        let maxForce: CGFloat = 5
        
        let normalizedAlpha = (touch.force - minForce) / (maxForce - minForce)
        
        context!.setAlpha(normalizedAlpha)
        
        return lineWidth
    }
    
    func lineWidthForDrawing(context: CGContext?, touch: UITouch) -> CGFloat {
        var lineWidth = defaultLineWidth
        
        if touch.force > 0 {
            lineWidth = touch.force * forceSensitivity
        }
        
        return lineWidth
    }
    
    public func clearCanvas(_ animated: Bool) {
        if animated {
            UIView.animate(withDuration: 0.3, delay: 0, options: .curveEaseOut, animations: {
                self.alpha = 0
                applyButton.isButtonEnabled(false)
            }, completion: { finished in
                self.alpha = 1
                self.image = nil
                self.resetRect()
                self.tutorialLabel.isHidden(false, animated: true)
            })
        } else {
            image = nil
            resetRect()
            tutorialLabel.isHidden(false, animated: true)
            applyButton.isButtonEnabled(false)
        }
    }
}
