import UIKit
import AVFoundation

public enum SoundName {
    case error, success, yay, pop
}

var player: AVAudioPlayer?

public func playSound(_ sound: SoundName) {
    switch sound {
    case SoundName.error:
        guard let url = Bundle.main.url(forResource: "error", withExtension: "wav") else {
            print("URL not found")
            return
        }
        
        do {
            try AVAudioSession.sharedInstance().setCategory(.playback, mode: .default)
            try AVAudioSession.sharedInstance().setActive(true)
            
            player = try AVAudioPlayer(contentsOf: url, fileTypeHint: AVFileType.wav.rawValue)
            player!.play()
        } catch let error as NSError {
            print("Error: \(error.localizedDescription)")
        }
    case SoundName.success:
        guard let url = Bundle.main.url(forResource: "success", withExtension: "wav") else {
            print("URL not found")
            return
        }
        
        do {
            try AVAudioSession.sharedInstance().setCategory(.playback, mode: .default)
            try AVAudioSession.sharedInstance().setActive(true)
            
            player = try AVAudioPlayer(contentsOf: url, fileTypeHint: AVFileType.wav.rawValue)
            player!.play()
        } catch let error as NSError {
            print("Error: \(error.localizedDescription)")
        }
    case SoundName.yay:
        guard let url = Bundle.main.url(forResource: "yay", withExtension: "wav") else {
            print("URL not found")
            return
        }
        
        do {
            try AVAudioSession.sharedInstance().setCategory(.playback, mode: .default)
            try AVAudioSession.sharedInstance().setActive(true)
            
            player = try AVAudioPlayer(contentsOf: url, fileTypeHint: AVFileType.wav.rawValue)
            player!.play()
        } catch let error as NSError {
            print("Error: \(error.localizedDescription)")
        }
    default:
        guard let url = Bundle.main.url(forResource: "pop", withExtension: "wav") else {
            print("URL not found")
            return
        }
        
        do {
            try AVAudioSession.sharedInstance().setCategory(.playback, mode: .default)
            try AVAudioSession.sharedInstance().setActive(true)
            
            player = try AVAudioPlayer(contentsOf: url, fileTypeHint: AVFileType.wav.rawValue)
            player!.play()
        } catch let error as NSError {
            print("Error: \(error.localizedDescription)")
        }
    }
}
