import UIKit

public class ViewController: UIViewController {
    private var backgroundImageView: UIImageView!
    private var visualEffectView: UIVisualEffectView!
    private var squareView: SquareView!
    private var seperator: UIView!
    private var continueButton: UIButton!
    private var firstLabel: UILabel!
    private var secondLabel: UILabel!
    private var thirdLabel: UILabel!
    
    private let viewHeight = 440
    private let viewWidth = 640
    
    override public func viewDidLoad() {
        super.viewDidLoad()
        
        view.backgroundColor = #colorLiteral(red: 0, green: 0, blue: 0, alpha: 1)
        
        backgroundImageView = {
            let imageView = UIImageView(frame: CGRect(x: 0, y: 0, width: viewWidth, height: viewHeight))
            imageView.image = UIImage(named: "ios-11-background.jpg")
            imageView.alpha = 0.65
            imageView.contentMode = .scaleAspectFill
            return imageView
        }()
        view.addSubview(backgroundImageView)
        
        visualEffectView = {
            let view = UIVisualEffectView()
            view.frame = CGRect(x: 0, y: 0, width: viewWidth, height: viewHeight)
            return view
        }()
        view.addSubview(visualEffectView)
        
        squareView = {
            let view = SquareView(frame: CGRect(x: 0, y: 0, width: viewWidth, height: viewHeight))
            view.backgroundColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 0)
            view.clipsToBounds = true
            return view
        }()
        view.addSubview(squareView)
        
        seperator = {
            let view = UIView(frame: CGRect(x: 40, y: 128, width: 309, height: 1))
            view.backgroundColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 0.07644696303)
            return view
        }()
        squareView.addSubview(seperator)
        
        continueButton = {
            let button = UIButton(type: .system)
            button.frame = CGRect(x: viewWidth - 128, y: viewHeight - 55, width: 88, height: 25)
            button.setTitle("Continue", for: .normal)
            button.titleLabel?.font = UIFont.systemFont(ofSize: 13, weight: .regular)
            button.layer.cornerRadius = 5
            button.layer.borderWidth = 1
            button.layer.borderColor = #colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)
            button.backgroundColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 0)
            button.setTitleColor(#colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0), for: .normal)
            button.addTarget(self, action: #selector(continuePressed), for: .touchUpInside)
            button.alpha = 0
            return button
        }()
        view.addSubview(continueButton)
        
        firstLabel = {
            let label = UILabel(frame: CGRect(x: 40, y: 75, width: 204, height: 24))
            label.text = "WWDC19 Playground"
            label.font = UIFont.systemFont(ofSize: 20, weight: .bold)
            label.textColor = #colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)
            return label
        }()
        squareView.addSubview(firstLabel)
        
        secondLabel = {
            let label = UILabel(frame: CGRect(x: 40, y: Int(firstLabel.frame.maxY) + 3, width: 125, height: 16))
            label.text = "By Benjamin Hutter"
            label.font = UIFont.systemFont(ofSize: 14, weight: .regular)
            label.textColor = UIColor.systemBlue
            return label
        }()
        squareView.addSubview(secondLabel)
        
        thirdLabel = {
            let label = UILabel(frame: CGRect(x: 40, y: viewHeight - 62, width: 250, height: 32))
            label.font = UIFont.systemFont(ofSize: 13, weight: .regular)
            label.text = "Welcome to my playground!\nI hope you’ll like it."
            label.numberOfLines = 2
            label.textColor = UIColor.systemGray
            return label
        }()
        squareView.addSubview(thirdLabel)
    }
    
    @objc public func continuePressed() {
        UIView.animate(withDuration: 0.5, delay: 0, options: .curveEaseOut, animations: {
            self.squareView.frame.origin.x = -390
            self.continueButton.alpha = 0
            self.visualEffectView.effect = UIBlurEffect(style: .regular)
            let textViewController = TextViewController()
            textViewController.modalPresentationStyle = .overCurrentContext
            self.present(textViewController, animated: false, completion: nil)
        }, completion: nil)
        
        playSound(.pop)
    }
    
    override public func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(true)
        
        UIView.animate(withDuration: 0.5, delay: 2.5, animations: {
            self.continueButton.alpha = 1
        }, completion: nil)
    }
}
