import UIKit
import AVFoundation

public class TextViewController: UIViewController {
    private var titleLabel: UILabel!
    private var speakButton: UIButton!
    private var textLabel: UILabel!
    private var imageView: UIImageView!
    private var secondImageView: UIImageView!
    private var continueButton: UIButton!
    
    private let text = "This idea behind this playground is to make it easier for children to learn writing numbers with the help of technology. I use CoreML/Vision and MNIST to support students in the learning process and to explore and demonstrate new and modern ways of teaching.\nI want to combine current technologies from our time with the best learning experience to get more young people excited about technology and provide them with an easy-to-use experience that allows them to study seamlessly."
    
    private let viewHeight = 440
    private let viewWidth = 640
    
    private let synth = AVSpeechSynthesizer()
    
    override public func viewDidLoad() {
        super.viewDidLoad()
        
        view.backgroundColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 0)
        
        titleLabel = {
            let label = UILabel(frame: CGRect(x: 50, y: 75, width: 365, height: 24))
            label.text = "What is this playground about?"
            label.textColor = #colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)
            label.font = UIFont.systemFont(ofSize: 20, weight: .bold)
            label.alpha = 0
            return label
        }()
        view.addSubview(titleLabel)
        
        speakButton = {
            let button = UIButton(type: .system)
            button.frame = CGRect(x: 350, y: titleLabel.frame.origin.y, width: titleLabel.frame.height, height: titleLabel.frame.height)
            button.setImage(UIImage(named: "audio@3x"), for: .normal)
            button.tintColor = #colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)
            button.addTarget(self, action: #selector(speak), for: .touchUpInside)
            button.alpha = 0
            return button
        }()
        view.addSubview(speakButton)
        
        textLabel = {
            let label = UILabel(frame: CGRect(x: 50, y: titleLabel.frame.origin.y + titleLabel.frame.height + 10, width: titleLabel.frame.width, height: 140))
            label.text = text
            label.textColor = UIColor.systemGray
            label.font = UIFont.systemFont(ofSize: 13, weight: .regular)
            label.numberOfLines = 0
            label.alpha = 0
            return label
        }()
        view.addSubview(textLabel)
        
        imageView = {
            let imageView = UIImageView(frame: CGRect(x: 465, y: 75, width: 125, height: 125))
            imageView.image = UIImage(named: "consultations.jpg")
            imageView.alpha = 0
            return imageView
        }()
        view.addSubview(imageView)
        
        secondImageView = {
            let imageView = UIImageView(frame: CGRect(x: 75, y: 300, width: 304, height: 90))
            imageView.image = UIImage(named: "technologies.png")
            imageView.alpha = 0
            return imageView
        }()
        view.addSubview(secondImageView)
        
        continueButton = {
            let button = UIButton(type: .system)
            button.frame = CGRect(x: viewWidth - 128, y: viewHeight - 75, width: 88, height: 25)
            button.setTitle("Continue", for: .normal)
            button.titleLabel?.font = UIFont.systemFont(ofSize: 13, weight: .regular)
            button.layer.cornerRadius = 5
            button.layer.borderWidth = 1
            button.layer.borderColor = #colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)
            button.backgroundColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 0)
            button.setTitleColor(#colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0), for: .normal)
            button.addTarget(self, action: #selector(continuePressed), for: .touchUpInside)
            button.alpha = 0
            return button
        }()
        view.addSubview(continueButton)
    }
    
    @objc public func continuePressed() {
        let mainViewController = MainViewController()
        mainViewController.modalPresentationStyle = .overCurrentContext
        present(mainViewController, animated: false, completion: nil)
        
        playSound(.pop)
        synth.stopSpeaking(at: .immediate)
    }
    
    override public func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(true)
        
        UIView.animate(withDuration: 0.75) {
            self.view.backgroundColor = UIColor.systemDarkPurple
        }
        
        UIView.animate(withDuration: 0.75, delay: 2, options: .autoreverse, animations: {
            self.speakButton.transform = CGAffineTransform(scaleX: 1.5, y: 1.5)
        }, completion: { (finished: Bool) in
            self.speakButton.transform = CGAffineTransform.identity
        })
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
            self.titleLabel.fadeTransition(0.5)
            self.textLabel.fadeTransition(0.5)
            self.speakButton.fadeTransition(0.5)
            self.imageView.fadeTransition(0.5)
            self.secondImageView.fadeTransition(0.5)
            self.titleLabel.alpha = 1
            self.textLabel.alpha = 1
            self.speakButton.alpha = 1
            self.imageView.alpha = 1
            self.secondImageView.alpha = 1
        }
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 3.5) {
            self.continueButton.fadeTransition(0.5)
            self.continueButton.alpha = 1
        }
    }
    
    @objc public func speak() {
        let message = AVSpeechUtterance(string: textLabel.text!)
        message.voice = AVSpeechSynthesisVoice(language: "en")
        
        synth.speak(message)
        
        playSound(.pop)
    }
}
