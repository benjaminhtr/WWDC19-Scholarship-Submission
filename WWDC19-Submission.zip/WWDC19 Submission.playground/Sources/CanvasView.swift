import UIKit

public class CanvasView: UIView {
    public override init(frame: CGRect) {
        super.init(frame: frame)
        
        configure()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    public func configure() {
        backgroundColor = #colorLiteral(red: 0, green: 0, blue: 0, alpha: 1)
        layer.cornerRadius = 10
        layer.shadowColor = UIColor.black.cgColor
        layer.shadowOffset = CGSize(width: 0, height: 3)
        layer.shadowRadius = 3
        layer.shadowOpacity = 0.16
        
        canvas = {
            let canvas = Canvas(frame: CGRect(x: 15, y: 15, width: frame.width - 30, height: frame.height - 30))
            canvas.isUserInteractionEnabled = true
            canvas.setup()
            return canvas
        }()
        addSubview(canvas)
        
        let canvasBorder: UIImageView = {
            let imageView = UIImageView(frame: canvas.frame)
            imageView.image = UIImage(named: "canvasBorder@3x")
            return imageView
        }()
        addSubview(canvasBorder)
    }
}
