/*:
 
 # Welcome
 
 Welcome to my WWDC19 scholarship playground. You're about to learn the power of Core ML/Vision. This playground helps children to learn numbers by the help of technology. Have fun while using! 😃
 
 ---
*/
import UIKit
import PlaygroundSupport
/*:
 ---
 
 ## Structure 💻
 - About this playground 🧒
 - What is a Convolutional Neural Network? 🤔
 - What is the MNIST database? ✍️
 - Get ready to run the code 🏃‍♂️
 ---
 
 ## About this playground 🧒
 This idea behind this playground is to make it easier for children to learn writing numbers with the help of technology. I use CoreML/Vision and MNIST to support students in the learning process and to explore and demonstrate new and modern ways of teaching.
 
 I want to combine current technologies from our time with the best learning experience to get more young people excited about technology and provide them with an easy-to-use experience that allows them to study seamlessly.
 
 ### But why?
 
 Some children in elementary school have deep problems with math. Affected children can’t combine logic with the visual representation of numbers, which is why they continuosly make mistakes, even though they might have gotten it right once before.
 
 They often have problems realizing the relationships between different numbers and how they are associated with each other. Neither do they have an idea or feeling for how high a number might be. Because this is a clear problem in our society, I decided to counter this and develop this playground.
 
 ---
 
 ## What is a Convolutional Neural Network? 🤔
 "A Convolutional Neural Network is an artificial neural network. It's a biological-inspired concept in machine learning. Convolutional Neural Networks are used in many modern artificial intelligence technologies, especially in the processing of image or audio data. A Convolutional Neural Network consists of one or more Convolutional Layer and a Pooling Layer"
 
 [wikipedia.org/wiki/Convolutional_neural_network](https://en.wikipedia.org/wiki/Convolutional_neural_network) 👈
 
 ---
 
 ## What is the MNIST database? ✍️
 Now we know what a Convolutional Neural Network is, but what is the MNIST dabase?
 
 Well, it's a huge databse of **28x28 pixel images** of handwritten digits (0-9). In the area of machine learning it's the most famous database since **1999** when it was created by **[Yann LeCun](http://yann.lecun.com/)**, **Corinna Cortes** and **[Christopher J. C. Burges](http://chrisburges.net)**. It has 60,000 grayscale images under the training set and 10,000 grayscale images under the test set.
 
 ---
 
 ### Example of some digits
 ![A MNIST Database example](MNIST.png)
 
 ---
 
 ### The layers of our model
 **Feature Learning**
 1. Input (28x28 pixel image)
 2. Convolution + Relu
 3. Pooling
 4. Convolution + Relu
 5. Pooling
 
 **Classification**
 
 6. Flatten
 7. Fully connected
 8. Softmax
 
 ---
 
 ## Get ready to run the code 🏃‍♂️
 
 ### Rules
 - If number is right: +5 points
 - If number is wrong: -5 points
 
 - Note: Try to reach 25, 50 or even 100 points. 🤫
 
 ---
 
 👇 Run the code below to start the playground.
 
*/
let viewController = ViewController()
viewController.preferredContentSize = CGSize(width: 640, height: 440)
PlaygroundPage.current.liveView = viewController
